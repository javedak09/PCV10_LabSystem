ABOUT
=====

jQuery.ptTimeSelect v0.8

jQuery.ptTimeSelect is a jQuery plugin for usage on input fields
that displays a popup widget allowing a user to define a time,
which is written back to an input field.

 
AUTHOR
------

Paul Tavares, <http://www.purtuga.com>

<http://pttimeselect.sourceforge.net>


LICENSE
-------
 
Copyright (c) 2007-2012 Paul T. <http://www.purtuga.com>

Licensed under the same terms as jQuery:

-   MIT - <http://www.opensource.org/licenses/mit-license.php>
-   GPL - <http://www.opensource.org/licenses/gpl-license.php>
    
User can pick whichever one applies best for their project
and does not have to contact me.



CHANGE LOG
==========

Version 0.8
-----------

*   **3554560** Documentation needs to be clearer and not as complex
                (<https://sourceforge.net/tracker/?func=detail&aid=3554560&group_id=190063&atid=931834>)
*   **3549413** does not support use of jQuery.noConflict() 
                (<https://sourceforge.net/tracker/?func=detail&aid=3554560&group_id=190063&atid=931834>)
*   Simplified packaging - only contains minimal set of file (reduce confusion)
*   Move to Markdown documenation.
*   Updates to website 




