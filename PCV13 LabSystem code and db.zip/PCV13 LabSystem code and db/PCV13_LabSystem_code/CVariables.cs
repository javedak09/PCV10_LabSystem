﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CVariables
/// </summary>
public class CVariables
{
    static string EmpNo = "";
    static string FTag = "";
    static string Loc = "";
    static int count = 0;
    static string fileexists = "";


    static string val_Q15c1 = "";
    static string val_Q15c2 = "";
    static string val_Q15c3 = "";
    static string val_Q15c4 = "";
    static string val_Q15c5 = "";
    static string val_Q15c6 = "";
    static string val_Q15c7 = "";

    static string val_Q16c1 = "";
    static string val_Q16c2 = "";
    static string val_Q16c3 = "";

    static string val_Q17c1 = "";
    static string val_Q17c2 = "";
    static string val_Q17c3 = "";
    static string val_Q17c4 = "";
    static string val_Q17c5 = "";
    static string val_Q17c6 = "";
    static string val_Q17c7 = "";
    static string val_Q17c8 = "";
    static string val_Q17c9 = "";
    static string val_Q17c10 = "";
    static string val_Q17c11 = "";

    static string val_Q18c1 = "";

    static bool val_IsEntered = false;
    static bool val_IsEntered1 = false;

    static bool IsUpdate = false;


    public CVariables()
    {
        //
        // TODO: Add constructor logic here
        //        
    }

    public static string empNo
    {
        get
        {
            return EmpNo;
        }

        set
        {
            EmpNo = value;
        }
    }


    public static bool IsRecordUpdate
    {
        get
        {
            return IsUpdate;
        }

        set
        {
            IsUpdate = value;
        }
    }


    public static string fTag
    {
        get
        {
            return FTag;
        }

        set
        {
            FTag = value;
        }
    }


    public static string loc
    {
        get
        {
            return Loc;
        }

        set
        {
            Loc = value;
        }
    }


    public static int counter
    {
        get
        {
            return count;
        }

        set
        {
            count = value;
        }
    }


    public static string IsFileExists
    {
        get
        {
            return fileexists;
        }

        set
        {
            fileexists = value;
        }
    }






    public static string Store_Q15c1
    {
        get
        {
            return val_Q15c1;
        }

        set
        {
            val_Q15c1 = value;
        }
    }


    public static string Store_Q15c2
    {
        get
        {
            return val_Q15c2;
        }

        set
        {
            val_Q15c2 = value;
        }
    }


    public static string Store_Q15c3
    {
        get
        {
            return val_Q15c3;
        }

        set
        {
            val_Q15c3 = value;
        }
    }


    public static string Store_Q15c4
    {
        get
        {
            return val_Q15c4;
        }

        set
        {
            val_Q15c4 = value;
        }
    }


    public static string Store_Q15c5
    {
        get
        {
            return val_Q15c5;
        }

        set
        {
            val_Q15c5 = value;
        }
    }


    public static string Store_Q15c6
    {
        get
        {
            return val_Q15c6;
        }

        set
        {
            val_Q15c6 = value;
        }
    }


    public static string Store_Q15c7
    {
        get
        {
            return val_Q15c7;
        }

        set
        {
            val_Q15c7 = value;
        }
    }



    public static string Store_Q16c1
    {
        get
        {
            return val_Q16c1;
        }

        set
        {
            val_Q16c1 = value;
        }
    }



    public static string Store_Q16c2
    {
        get
        {
            return val_Q16c2;
        }

        set
        {
            val_Q16c2 = value;
        }
    }



    public static string Store_Q16c3
    {
        get
        {
            return val_Q16c3;
        }

        set
        {
            val_Q16c3 = value;
        }
    }



    public static string Store_Q17c1
    {
        get
        {
            return val_Q17c1;
        }

        set
        {
            val_Q17c1 = value;
        }
    }


    public static string Store_Q17c2
    {
        get
        {
            return val_Q17c2;
        }

        set
        {
            val_Q17c2 = value;
        }
    }


    public static string Store_Q17c3
    {
        get
        {
            return val_Q17c3;
        }

        set
        {
            val_Q17c3 = value;
        }
    }



    public static string Store_Q17c4
    {
        get
        {
            return val_Q17c4;
        }

        set
        {
            val_Q17c4 = value;
        }
    }



    public static string Store_Q17c5
    {
        get
        {
            return val_Q17c5;
        }

        set
        {
            val_Q17c5 = value;
        }
    }



    public static string Store_Q17c6
    {
        get
        {
            return val_Q17c6;
        }

        set
        {
            val_Q17c6 = value;
        }
    }



    public static string Store_Q17c7
    {
        get
        {
            return val_Q17c7;
        }

        set
        {
            val_Q17c7 = value;
        }
    }



    public static string Store_Q17c8
    {
        get
        {
            return val_Q17c8;
        }

        set
        {
            val_Q17c8 = value;
        }
    }



    public static string Store_Q17c9
    {
        get
        {
            return val_Q17c9;
        }

        set
        {
            val_Q17c9 = value;
        }
    }



    public static string Store_Q17c10
    {
        get
        {
            return val_Q17c10;
        }

        set
        {
            val_Q17c10 = value;
        }
    }



    public static string Store_Q17c11
    {
        get
        {
            return val_Q17c11;
        }

        set
        {
            val_Q17c11 = value;
        }
    }



    public static string Store_Q18c1
    {
        get
        {
            return val_Q18c1;
        }

        set
        {
            val_Q18c1 = value;
        }
    }



    public static bool IsEntered
    {
        get
        {
            return val_IsEntered;
        }

        set
        {
            val_IsEntered = value;
        }
    }


    public static bool IsEntered1
    {
        get
        {
            return val_IsEntered1;
        }

        set
        {
            val_IsEntered1 = value;
        }
    }





}